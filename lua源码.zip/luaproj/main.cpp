#include <stdio.h>
extern "C" {
	#include "lua/lua.h"
	#include "lua/lualib.h"
	#include "lua/lauxlib.h"
}

int main(int ar)
{
	printf("test\n");
	lua_State* L = lua_open();

	luaL_openlibs(L);
	luaL_dofile(L, "my.lua");
	return 0;
}
 