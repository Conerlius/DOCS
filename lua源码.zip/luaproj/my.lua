local a = 3444
print("a = "..a)

local tab = {
	[-90] = 901,
	[1] = 34,
	[2] = 32,
	[3] = 33,
	[4] = 4,
}

for k,v in pairs(tab) do
	print("k = "..k.." v = "..v)
end
